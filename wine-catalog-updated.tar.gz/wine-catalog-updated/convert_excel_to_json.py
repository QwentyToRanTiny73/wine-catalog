#!/usr/bin/env python3
"""
Скрипт для конвертации Excel файла базы данных вин в JSON формат
Использование: python3 convert_excel_to_json.py БД_133_образца_исправлено.xlsx
"""

import pandas as pd
import json
import sys
import os

def convert_excel_to_json(excel_file, output_file='data.json'):
    """
    Конвертирует Excel файл БД вин в JSON
    
    Args:
        excel_file (str): Путь к Excel файлу
        output_file (str): Путь к выходному JSON файлу
    """
    try:
        # Читаем Excel файл (пропускаем первые 2 строки с объединёнными заголовками)
        print(f"📖 Чтение файла: {excel_file}")
        df = pd.read_excel(excel_file, skiprows=2)
        
        # Переименовываем колонки (убираем Unnamed)
        columns_map = {}
        for i, col in enumerate(df.columns):
            if 'Unnamed' in str(col):
                new_name = df.iloc[0, i]
                if pd.notna(new_name) and str(new_name).strip():
                    columns_map[col] = str(new_name).strip()
        
        df.rename(columns=columns_map, inplace=True)
        
        # Удаляем первую строку (которую использовали для заголовков)
        df = df.iloc[1:].reset_index(drop=True)
        
        # Очищаем пустые строки
        df = df[df.iloc[:, 0].notna()].copy()
        
        print(f"✅ Загружено образцов: {len(df)}")
        
        # Конвертируем в JSON
        wine_records = []
        for idx, row in df.iterrows():
            record = {
                'id': int(idx + 1),
                'date': str(row.get('Дата исследования', '')),
                'district': str(row.get('Административный район выращивания винграда', 'nan')).strip(),
                'producer': str(row.get('Производитель вина (винодельня)', 'nan')).strip(),
                'name': str(row.get('Наименование образца', '')).strip(),
                'variety': str(row.get('Сортовой состав', '')).strip(),
                'year': int(row.get('Год урожая', 0)) if pd.notna(row.get('Год урожая')) else None,
                'color': str(row.get('Цвет', '')).lower().strip(),
                'type': str(row.get('Тип винодельческой продукции', '')).strip(),
                'alcohol': float(row.get('Объемная доля этилового спирта', 0)) if pd.notna(row.get('Объемная доля этилового спирта')) else None,
                'extract': float(row.get('Приведенный экстракт', 0)) if pd.notna(row.get('Приведенный экстракт')) else None,
                'acidity': float(row.get('Титруемая кислотность', 0)) if pd.notna(row.get('Титруемая кислотность')) else None,
                'sugars': float(row.get('Сахара', 0)) if pd.notna(row.get('Сахара')) else None,
                'citric_acid': float(row.get('Лимонная кислота', 0)) if pd.notna(row.get('Лимонная кислота')) else None,
                'tartaric_acid': float(row.get('Винная кислота', 0)) if pd.notna(row.get('Винная кислота')) else None,
                'malic_acid': float(row.get('Яблочная кислота', 0)) if pd.notna(row.get('Яблочная кислота')) else None,
                'lactic_acid': float(row.get('Молочная кислота', 0)) if pd.notna(row.get('Молочная кислота')) else None,
                'acetic_acid': float(row.get('Уксусная кислота', 0)) if pd.notna(row.get('Уксусная кислота')) else None,
                'ph': float(row.get('Физико-химические характеристики', 0)) if pd.notna(row.get('Физико-химические характеристики')) else None,  # pH
                'conductivity': float(row.get('Электропроводность', 0)) if pd.notna(row.get('Электропроводность')) else None,
                'phenolics': int(row.get('Сумма фенольных веществ', 0)) if pd.notna(row.get('Сумма фенольных веществ')) else None,
                'glycerol': float(row.get('Глицерин', 0)) if pd.notna(row.get('Глицерин')) else None
            }
            
            # Заменяем 'nan' на пустую строку
            for key, value in record.items():
                if value == 'nan':
                    record[key] = ''
            
            wine_records.append(record)
        
        # Сохраняем в JSON
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(wine_records, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Конвертировано записей: {len(wine_records)}")
        print(f"✅ Сохранено в: {output_file}")
        print(f"\n📊 Пример первой записи:")
        print(json.dumps(wine_records[0], ensure_ascii=False, indent=2))
        
    except FileNotFoundError:
        print(f"❌ Ошибка: Файл {excel_file} не найден!")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Ошибка при конвертации: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Использование: python3 convert_excel_to_json.py <excel_file>")
        print("Пример: python3 convert_excel_to_json.py БД_133_образца_исправлено.xlsx")
        sys.exit(1)
    
    excel_file = sys.argv[1]
    
    if not os.path.exists(excel_file):
        print(f"❌ Файл {excel_file} не найден!")
        sys.exit(1)
    
    convert_excel_to_json(excel_file)
