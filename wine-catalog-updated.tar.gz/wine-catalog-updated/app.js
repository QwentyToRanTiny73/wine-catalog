// Глобальные переменные
let wineData = [];
let filteredData = [];
let isAdmin = false;

// Имитация данных (в реальном приложении загружаются из файла или API)
const sampleWineData = [
    {
        id: 1,
        date: "12.08.2025",
        district: "ЮБК",
        producer: "Массандра",
        name: "Мускат белый",
        variety: "Мускат белый",
        year: 2024,
        color: "белое",
        type: "в",
        alcohol: 13.2,
        extract: 25.4,
        acidity: 5.0,
        sugars: 1.20,
        citric_acid: 0.15,
        tartaric_acid: 3.2,
        malic_acid: 0.8,
        lactic_acid: 0.1,
        acetic_acid: 0.05,
        ph: 3.26,
        conductivity: 1.67,
        phenolics: 187,
        glycerol: 7.5
    },
    {
        id: 2,
        date: "10.08.2025",
        district: "Бахчисарайский",
        producer: "Инкерманский завод",
        name: "Саперави",
        variety: "Саперави 100%",
        year: 2023,
        color: "красное",
        type: "в",
        alcohol: 14.3,
        extract: 28.5,
        acidity: 5.3,
        sugars: 2.60,
        citric_acid: 0.12,
        tartaric_acid: 2.8,
        malic_acid: 0.5,
        lactic_acid: 1.2,
        acetic_acid: 0.08,
        ph: 3.57,
        conductivity: 2.18,
        phenolics: 2958,
        glycerol: 9.2
    },
    {
        id: 3,
        date: "08.08.2025",
        district: "Севастополь",
        producer: "Pavel Shvets",
        name: "Каберне-Мерло",
        variety: "Каберне Совиньон 60%, Мерло 40%",
        year: 2022,
        color: "красное",
        type: "в",
        alcohol: 15.3,
        extract: 30.2,
        acidity: 7.1,
        sugars: 2.30,
        citric_acid: 0.10,
        tartaric_acid: 3.5,
        malic_acid: 0.3,
        lactic_acid: 1.8,
        acetic_acid: 0.12,
        ph: 2.96,
        conductivity: 1.43,
        phenolics: 2788,
        glycerol: 10.5
    }
];

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    loadWineData(); // populateFilters() вызывается внутри loadWineData()
});

// Проверка авторизации
function checkAuth() {
    isAdmin = localStorage.getItem('isAdmin') === 'true';
    updateAuthUI();
}

// Обновление UI в зависимости от роли
function updateAuthUI() {
    const authButton = document.getElementById('authButton');
    const adminNavItem = document.getElementById('adminNavItem');
    
    if (isAdmin) {
        authButton.innerHTML = '<i class="fas fa-sign-out-alt me-1"></i>Выход';
        authButton.onclick = logout;
        authButton.removeAttribute('data-bs-toggle');
        authButton.removeAttribute('data-bs-target');
        adminNavItem.style.display = 'block';
    } else {
        authButton.innerHTML = '<i class="fas fa-sign-in-alt me-1"></i>Вход';
        authButton.onclick = null;
        authButton.setAttribute('data-bs-toggle', 'modal');
        authButton.setAttribute('data-bs-target', '#authModal');
        adminNavItem.style.display = 'none';
    }
}

// Авторизация
function login() {
    const login = document.getElementById('authLogin').value;
    const password = document.getElementById('authPassword').value;
    
    // Простая проверка (в реальном приложении должна быть серверная авторизация)
    if (login === 'admin' && password === 'magarach2024') {
        isAdmin = true;
        localStorage.setItem('isAdmin', 'true');
        updateAuthUI();
        
        // Закрываем модальное окно
        const authModal = bootstrap.Modal.getInstance(document.getElementById('authModal'));
        authModal.hide();
        
        // Очищаем поля
        document.getElementById('authLogin').value = '';
        document.getElementById('authPassword').value = '';
        
        showNotification('Вы успешно авторизованы как администратор', 'success');
    } else {
        showNotification('Неверный логин или пароль', 'danger');
    }
}

// Выход
function logout() {
    isAdmin = false;
    localStorage.removeItem('isAdmin');
    updateAuthUI();
    showNotification('Вы вышли из системы', 'info');
}

// Загрузка данных
async function loadWineData() {
    try {
        const response = await fetch('data.json');
        if (response.ok) {
            const data = await response.json();
            wineData = data;
            filteredData = [...wineData];
            renderTable();
            updateResultsCount();
            populateFilters(); // Обновляем фильтры после загрузки данных
        } else {
            // Если файл не найден, используем демо-данные
            wineData = [...sampleWineData];
            filteredData = [...wineData];
            renderTable();
            updateResultsCount();
            showNotification('Используются демонстрационные данные', 'info');
        }
    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
        wineData = [...sampleWineData];
        filteredData = [...wineData];
        renderTable();
        updateResultsCount();
        showNotification('Ошибка загрузки данных. Используются демо-данные.', 'warning');
    }
}

// Заполнение фильтров уникальными значениями
function populateFilters() {
    const districts = [...new Set(wineData.map(w => w.district))];
    const filterDistrict = document.getElementById('filterDistrict');
    
    districts.forEach(district => {
        const option = document.createElement('option');
        option.value = district;
        option.textContent = district;
        filterDistrict.appendChild(option);
    });
}

// Применение фильтров
function applyFilters() {
    const filterDistrict = document.getElementById('filterDistrict').value.toLowerCase();
    const filterVariety = document.getElementById('filterVariety').value.toLowerCase();
    const filterYear = document.getElementById('filterYear').value;
    const filterColor = document.getElementById('filterColor').value.toLowerCase();
    
    filteredData = wineData.filter(wine => {
        const matchDistrict = !filterDistrict || wine.district.toLowerCase().includes(filterDistrict);
        const matchVariety = !filterVariety || wine.variety.toLowerCase().includes(filterVariety);
        const matchYear = !filterYear || wine.year.toString() === filterYear;
        const matchColor = !filterColor || wine.color.toLowerCase() === filterColor;
        
        return matchDistrict && matchVariety && matchYear && matchColor;
    });
    
    renderTable();
    updateResultsCount();
}

// Отображение таблицы
function renderTable() {
    const tbody = document.getElementById('wineTableBody');
    
    if (filteredData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center empty-state">
                    <i class="fas fa-search fa-3x mb-3 d-block opacity-25"></i>
                    <p class="mb-0">Образцы не найдены. Попробуйте изменить параметры фильтрации.</p>
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = filteredData.map((wine, index) => `
        <tr>
            <td>${index + 1}</td>
            <td><strong>${wine.name}</strong></td>
            <td>${wine.variety}</td>
            <td>${wine.year}</td>
            <td>${wine.district}</td>
            <td>
                <span class="wine-color-badge wine-color-${wine.color}"></span>
                ${wine.color.charAt(0).toUpperCase() + wine.color.slice(1)}
            </td>
            <td>${wine.alcohol ? wine.alcohol.toFixed(1) : '—'}</td>
            <td>${wine.sugars ? wine.sugars.toFixed(2) : '—'}</td>
            <td>
                <button class="btn btn-sm btn-info btn-details" onclick="showDetails(${wine.id})">
                    <i class="fas fa-info-circle"></i> Дополнительно
                </button>
            </td>
        </tr>
    `).join('');
}

// Показ детальной информации
function showDetails(wineId) {
    const wine = wineData.find(w => w.id === wineId);
    if (!wine) return;
    
    // Заполняем блок ГОСТ
    const gostParams = document.getElementById('gostParameters');
    gostParams.innerHTML = `
        <tr>
            <td>Объёмная доля этилового спирта</td>
            <td><strong>${wine.alcohol ? wine.alcohol.toFixed(1) : '—'} % об.</strong></td>
        </tr>
        <tr>
            <td>Приведённый экстракт</td>
            <td><strong>${wine.extract ? wine.extract.toFixed(1) : '—'} г/дм³</strong></td>
        </tr>
        <tr>
            <td>Титруемая кислотность</td>
            <td><strong>${wine.acidity ? wine.acidity.toFixed(1) : '—'} г/дм³</strong></td>
        </tr>
        <tr>
            <td>Сахара</td>
            <td><strong>${wine.sugars ? wine.sugars.toFixed(2) : '—'} г/дм³</strong></td>
        </tr>
        <tr class="table-warning">
            <td>Лимонная кислота</td>
            <td><strong>${wine.citric_acid ? wine.citric_acid.toFixed(2) : '—'} г/дм³</strong></td>
        </tr>
    `;
    
    // Заполняем аналитический блок
    const analyticalParams = document.getElementById('analyticalParameters');
    analyticalParams.innerHTML = `
        <tr>
            <td>pH</td>
            <td><strong>${wine.ph ? wine.ph.toFixed(2) : '—'}</strong></td>
        </tr>
        <tr>
            <td>Электропроводность</td>
            <td><strong>${wine.conductivity ? wine.conductivity.toFixed(2) : '—'} мкСм/см</strong></td>
        </tr>
        <tr>
            <td>Сумма фенольных веществ</td>
            <td><strong>${wine.phenolics ? wine.phenolics : '—'} мг/дм³</strong></td>
        </tr>
        <tr>
            <td>Глицерин</td>
            <td><strong>${wine.glycerol ? wine.glycerol.toFixed(1) : '—'} г/дм³</strong></td>
        </tr>
    `;
    
    // Заполняем профиль органических кислот
    const organicAcids1 = document.getElementById('organicAcids1');
    organicAcids1.innerHTML = `
        <tr>
            <td>Винная кислота</td>
            <td><strong>${wine.tartaric_acid ? wine.tartaric_acid.toFixed(2) : '—'} г/дм³</strong></td>
        </tr>
        <tr>
            <td>Яблочная кислота</td>
            <td><strong>${wine.malic_acid ? wine.malic_acid.toFixed(2) : '—'} г/дм³</strong></td>
        </tr>
    `;
    
    const organicAcids2 = document.getElementById('organicAcids2');
    organicAcids2.innerHTML = `
        <tr>
            <td>Молочная кислота</td>
            <td><strong>${wine.lactic_acid ? wine.lactic_acid.toFixed(2) : '—'} г/дм³</strong></td>
        </tr>
        <tr>
            <td>Уксусная кислота</td>
            <td><strong>${wine.acetic_acid ? wine.acetic_acid.toFixed(2) : '—'} г/дм³</strong></td>
        </tr>
    `;
    
    // Показываем модальное окно
    const detailsModal = new bootstrap.Modal(document.getElementById('detailsModal'));
    detailsModal.show();
}

// Добавление нового образца
function addNewSample() {
    if (!isAdmin) {
        showNotification('Только администратор может добавлять образцы', 'danger');
        return;
    }
    
    // Собираем данные из формы
    const newSample = {
        id: wineData.length + 1,
        date: document.getElementById('newDate').value,
        district: document.getElementById('newDistrict').value,
        producer: document.getElementById('newProducer').value,
        name: document.getElementById('newName').value,
        variety: document.getElementById('newVariety').value,
        year: parseInt(document.getElementById('newYear').value),
        color: document.getElementById('newColor').value,
        type: document.getElementById('newType').value,
        alcohol: parseFloat(document.getElementById('newAlcohol').value) || null,
        extract: parseFloat(document.getElementById('newExtract').value) || null,
        acidity: parseFloat(document.getElementById('newAcidity').value) || null,
        sugars: parseFloat(document.getElementById('newSugars').value) || null,
        citric_acid: parseFloat(document.getElementById('newCitric').value) || null,
        tartaric_acid: parseFloat(document.getElementById('newTartaric').value) || null,
        malic_acid: parseFloat(document.getElementById('newMalic').value) || null,
        lactic_acid: parseFloat(document.getElementById('newLactic').value) || null,
        ph: parseFloat(document.getElementById('newPH').value) || null,
        conductivity: parseFloat(document.getElementById('newConductivity').value) || null,
        phenolics: parseInt(document.getElementById('newPhenolics').value) || null,
        glycerol: parseFloat(document.getElementById('newGlycerol').value) || null
    };
    
    // Проверка обязательных полей
    if (!newSample.name || !newSample.year || !newSample.color) {
        showNotification('Заполните обязательные поля: Наименование, Год урожая, Цвет', 'warning');
        return;
    }
    
    // Добавляем в массив
    wineData.push(newSample);
    filteredData = [...wineData];
    
    // Обновляем таблицу
    renderTable();
    updateResultsCount();
    
    // Закрываем модальное окно
    const addModal = bootstrap.Modal.getInstance(document.getElementById('addSampleModal'));
    addModal.hide();
    
    // Очищаем форму
    clearAddForm();
    
    showNotification('Образец успешно добавлен!', 'success');
}

// Очистка формы добавления
function clearAddForm() {
    const form = document.querySelector('#addSampleModal form');
    if (form) form.reset();
    
    // Очищаем все поля вручную
    ['newDate', 'newDistrict', 'newProducer', 'newName', 'newVariety', 'newYear', 
     'newColor', 'newType', 'newAlcohol', 'newExtract', 'newAcidity', 'newSugars',
     'newCitric', 'newTartaric', 'newMalic', 'newLactic', 'newPH', 
     'newConductivity', 'newPhenolics', 'newGlycerol'].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = '';
    });
}

// Обновление счётчика результатов
function updateResultsCount() {
    document.getElementById('resultsCount').textContent = `${filteredData.length} образцов`;
}

// Показ уведомлений
function showNotification(message, type = 'info') {
    // Создаём уведомление в стиле Bootstrap toast
    const toastHTML = `
        <div class="toast align-items-center text-white bg-${type} border-0 position-fixed top-0 end-0 m-3" role="alert" style="z-index: 9999;">
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    
    const toastContainer = document.createElement('div');
    toastContainer.innerHTML = toastHTML;
    document.body.appendChild(toastContainer);
    
    const toastElement = toastContainer.querySelector('.toast');
    const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
    toast.show();
    
    // Удаляем элемент после скрытия
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastContainer.remove();
    });
}

// Экспорт функций для использования в HTML
window.applyFilters = applyFilters;
window.showDetails = showDetails;
window.login = login;
window.logout = logout;
window.addNewSample = addNewSample;
